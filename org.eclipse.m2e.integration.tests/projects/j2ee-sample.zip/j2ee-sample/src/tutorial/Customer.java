package tutorial;

import java.util.ArrayList;
import java.util.List;
import java.util.Iterator;

public class Customer {

  private Integer id;
  private String name;
  private boolean active;
  private List orders;
  private double balanceOutstanding;
  private double creditLimit;
  private long version;
  
  protected Customer() {
    this.orders = new ArrayList();
  }

  public Customer(String name) {
    this();
    setName(name);
    setActive(true);
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    if (name != null) {
      name = name.trim();
    }
    if (name == null || name.length() == 0) {
      throw new IllegalArgumentException("Name cannot be null or blank");
    }
    if (name.indexOf('\r') >= 0 || name.indexOf('\n') >= 0) {
      throw new IllegalArgumentException(
          "Name cannot contain newline or return characters");
    }
    this.name = name;
  }

  public boolean isActive() {
    return active;
  }

  public void setActive(boolean active) {
    this.active = active;
  }

  public void addOrder(Order order) throws CreditException {
    if (!active) {
      throw new IllegalStateException("Customer is not active");
    }

    if (order == null) {
      throw new IllegalArgumentException("Order cannot be null");
    }

    if (balanceOutstanding + order.getAmountDue() > creditLimit) {
      active = false;
      throw new CreditException("Credit limit exceeded");
    }

    balanceOutstanding += order.getAmountDue();
    orders.add(order);
    order.setCustomer(this);
  }

  public void addOrders(List newOrders) throws CreditException {
    for (Iterator iterator = newOrders.iterator(); iterator.hasNext();) {
      addOrder((Order) iterator.next());
    }
  }

  public void makePayment(double amount) {
    if (amount <= 0) {
      throw new IllegalArgumentException("Payment cannot be zero or negative");
    }
    this.balanceOutstanding -= amount;
  }

  public double getBalanceOutstanding() {
    return balanceOutstanding;
  }

  public void setCreditLimit(double creditLimit) {
    if (creditLimit < 0) {
      throw new IllegalArgumentException("Credit limit cannot be negative");
    }
    this.creditLimit = creditLimit;
  }

  public double getCreditLimit() {
    return creditLimit;
  }

  public Order[] getOrdersArray() {
    return (Order[]) orders.toArray(new Order[orders.size()]);
  }

  public boolean equals(Object other) {
    if (other instanceof Customer) {
      return name.equals(((Customer) other).name);
    }
    return false;
  }

  public String toString() {
    return name;
  }

  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public void setBalanceOutstanding(double balanceOutstanding) {
    this.balanceOutstanding = balanceOutstanding;
  }

  public List getOrders() {
    return orders;
  }

  public void setOrders(List orders) {
    this.orders = orders;
  }

  
  public long getVersion() {
    return version;
  }

  
  public void setVersion(long ver) {
    this.version = ver;
  }
}

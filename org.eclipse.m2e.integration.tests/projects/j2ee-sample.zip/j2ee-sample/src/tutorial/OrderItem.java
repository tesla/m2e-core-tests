package tutorial;

public class OrderItem {
  private Integer id;
  private Order order;
  private Product product;
  private int quantity;

  protected OrderItem() {}
  
  public OrderItem(Product product, int quantity) {
    if (product == null) {
      throw new IllegalArgumentException("Product cannot be null");
    }
    if (quantity < 0) {
      throw new IllegalArgumentException("Quantity cannot be negative");
    }
    
    this.product = product;
    this.quantity = quantity;
  }

  public Product getProduct() {
    return product;
  }

  public int getQuantity() {
    return quantity;
  }

  public double getCost(){
    return product.getPrice() * quantity;
  }

  public String toString() {
    return "" + product + " : " + quantity;
  }

  
  public Integer getId() {
    return id;
  }

  
  public void setId(Integer id) {
    this.id = id;
  }

  
  public Order getOrder() {
    return order;
  }

  
  public void setOrder(Order order) {
    this.order = order;
  }

  
  public void setProduct(Product product) {
    this.product = product;
  }

  
  public void setQuantity(int quantity) {
    this.quantity = quantity;
  }
}

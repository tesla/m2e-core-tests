package tutorial;

public class Product {
  private static final String CODE_MASK = "[A-Z]-\\d\\d\\d\\d-\\d\\d-[A-Z]";
  private Integer id;
  private String code;
  private String name;
  private double price;

  protected Product() {
  }

  /**
   * @param code  Must be of the form A-9999-99-A
   * @param name  Must not be null. Must not be longer than 20 characters.
   * @param price must be between $0 and $1000
   * @throws IllegalArgumentException if the code, name or price is invalid
   */
  public Product(String code, String name, double price) throws IllegalArgumentException {
    validateCode(code);
    validateName(name);
    validatePrice(price);
    this.code = code;
    this.name = name;
    this.price = price;
  }

  public String getCode() {
    return code;
  }

  public String getName() {
    return name;
  }

  /**
   * @param name Must not be null. Must not be longer than 20 characters.
   * @throws IllegalArgumentException if the name is invalid
   */
  public void setName(String name) throws IllegalArgumentException {
    validateName(name);
    this.name = name;
  }

  public double getPrice() {
    return price;
  }

  /**
   * @param price must be between $0 and $1000
   * @throws IllegalArgumentException if the price is out of range
   */
  public void setPrice(double price) throws IllegalArgumentException {
    validatePrice(price);
    this.price = price;
  }

  public String toString() {
    return code;
  }

  private void validateCode(String code) throws IllegalArgumentException {
    if (code == null || !code.matches(CODE_MASK)) {
      throw new IllegalArgumentException("Product code should be of the form A-9999-99-A");
    }
  }

  private void validateName(String name) throws IllegalArgumentException {
    if (name == null || name.length() == 0) {
      throw new IllegalArgumentException("Name cannot be null or blank");
    }
    if (name.length() > 20) {
      throw new IllegalArgumentException("Name cannot be longer than 20 characters");
    }
    if (name.indexOf('\r') >= 0 || name.indexOf('\n') >= 0) {
      throw new IllegalArgumentException("Name cannot contain newline or return characters");
    }
  }

  private void validatePrice(double price) throws IllegalArgumentException {
    if (price < 0 || price > 1000) {
      throw new IllegalArgumentException("Price must be between $0 and $1000");
    }
  }

  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public void setCode(String code) {
    validateCode(code);
    this.code = code;
  }
}

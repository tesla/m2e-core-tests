package tutorial.db;

import tutorial.Product;
import tutorial.web.Catalog;
import tutorial.web.DataAccessException;

import java.sql.ResultSet;

public class CatalogDAO {
  private static final String SELECT_CATALOG = "select productCode, productName, price from Products";
  private static final int PRODUCT_CODE_COLUMN = 1;
  private static final int PRODUCT_NAME_COLUMN = 2;
  private static final int PRODUCT_PRICE_COLUMN = 3;

  private DatabaseHelper db;

  public CatalogDAO(DatabaseHelper db) {
    if (db == null) {
      throw new NullPointerException("db must not be null");
    }
    this.db = db;
  }

  public Catalog getCatalog() throws DataAccessException {
    Catalog catalog = new Catalog();
    try {
      ResultSet result = db.select(SELECT_CATALOG);
      while (result.next()) {
        String code = result.getString(PRODUCT_CODE_COLUMN);
        String name = result.getString(PRODUCT_NAME_COLUMN);
        double price = result.getDouble(PRODUCT_PRICE_COLUMN);

        Product product = new Product(code, name, price);
        catalog.addProduct(product);
      }
      return catalog;
    }
    catch (Exception exception) {
      throw new DataAccessException("Could not read catalog details", exception);
    }
  }
}

package tutorial.db;

import tutorial.Customer;
import tutorial.web.DataAccessException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.NoSuchElementException;

class CustomerDAO {
  private static final String SELECT_CUSTOMER = "select active, creditLimit from Customers where customerName = ?";
  private static final int ACTIVE_COLUMN = 1;
  private static final int CREDIT_LIMIT_COLUMN = 2;

  private DatabaseHelper db;

  public CustomerDAO(DatabaseHelper db) {
    if (db == null) {
      throw new NullPointerException("db must not be null");
    }
    this.db = db;
  }

  public Customer getCustomer(String customerName) throws DataAccessException {
    try {
      ResultSet result = db.select(SELECT_CUSTOMER, customerName);
      Customer customer = readCustomer(result, customerName);
      new OrderDAO(db).populateOrdersForCustomer(customer);
      return customer;
    }
    catch(SQLException exception){
      throw new DataAccessException("Could not read customer details", exception);
    }
  }

  private Customer readCustomer(ResultSet result, String customerName) throws SQLException {
    if (result.next()) {
      Customer customer = new Customer(customerName);
      customer.setActive(result.getBoolean(ACTIVE_COLUMN));
      customer.setCreditLimit(result.getInt(CREDIT_LIMIT_COLUMN));
      return customer;
    }
    else {
      throw new NoSuchElementException("Customer does not exist [" + customerName + "]");
    }
  }
}

package tutorial.db;

import tutorial.Customer;
import tutorial.Order;
import tutorial.Product;
import tutorial.web.Catalog;
import tutorial.web.DataAccess;
import tutorial.web.DataAccessException;
import javax.naming.NamingException;
import javax.naming.InitialContext;
import javax.sql.DataSource;
import java.sql.SQLException;

public class JdbcDataAccess implements DataAccess {
  private static final String DATABASE_RESOURCE = "java:comp/env/jdbc/TutorialDB";

  private DataSource dataSource;
  private DatabaseHelper db;

  public JdbcDataAccess() throws NamingException {
    dataSource = (DataSource) new InitialContext().lookup(DATABASE_RESOURCE);
  }

  public Product getProduct(String productCode) throws DataAccessException {
    try {
      connect();
      return new ProductDAO(db).getProduct(productCode);
    }
    finally {
      disconnect();
    }
  }

  public Catalog getCatalog() throws DataAccessException {
    try {
      connect();
      return new CatalogDAO(db).getCatalog();
    }
    finally {
      disconnect();
    }
  }

  public void saveOrder(Customer customer, Order order) throws DataAccessException {
    try {
      connect();
      new OrderDAO(db).saveOrder(customer.getName(), order);
    }
    finally {
      disconnect();
    }
  }

  public Customer getCustomer(String name) throws DataAccessException {
    try {
      connect();
      return new CustomerDAO(db).getCustomer(name);
    }
    finally {
      disconnect();
    }
  }

  private void connect() throws DataAccessException {
    try {
      db = new DatabaseHelper(dataSource.getConnection());
    }
    catch (SQLException exception) {
      throw new DataAccessException("Could not connect to database", exception);
    }
  }

  private void disconnect() throws DataAccessException {
    if (db != null) {
      db.disconnect();
      db = null;
    }
  }
}

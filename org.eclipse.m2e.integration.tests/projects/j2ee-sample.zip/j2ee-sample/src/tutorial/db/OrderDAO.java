package tutorial.db;

import tutorial.Customer;
import tutorial.Order;
import tutorial.OrderItem;
import tutorial.Product;
import tutorial.web.DataAccessException;

import java.sql.ResultSet;
import java.sql.SQLException;

public class OrderDAO {
  private static final String INSERT_ORDER = "insert Orders";
  private static final String INSERT_ORDER_ITEM = "insert Orders";
  private static final String SELECT_ORDERS =
          "select orderNumber, orderDate, Products.productCode, productName, price, quantity" +
          " from Orders, Products" +
          " where customerName = ?" +
          " and Orders.productCode = Products.productCode" +
          " order by orderNumber";

  private static final int ORDER_NUMBER_COLUMN = 1;
  private static final int ORDER_DATE_COLUMN = 2;
  private static final int PRODUCT_CODE_COLUMN = 3;
  private static final int PRODUCT_NAME_COLUMN = 4;
  private static final int PRICE_COLUMN = 5;
  private static final int QUANTITY_COLUMN = 6;

  private DatabaseHelper db;

  public OrderDAO(DatabaseHelper db) {
    if (db == null) {
      throw new NullPointerException("db must not be null");
    }
    this.db = db;
  }

  public void saveOrder(String user, Order order) throws DataAccessException {
    try {
      db.insert(INSERT_ORDER, new Object[]{user, order.getOrderDate()});

      OrderItem[] items = order.getItemsArray();
      for (int i = 0; i < items.length; i++) {
        db.insert(INSERT_ORDER_ITEM, new Object[]{items});
      }
    }
    catch (SQLException exception) {
      throw new DataAccessException("Could not save order", exception);
    }
  }

  void populateOrdersForCustomer(Customer customer) throws DataAccessException {
    try {
      ResultSet result = db.select(SELECT_ORDERS);

      int lastNumber = 0;
      Order order = null;

      while (result.next()) {
        int currentNumber = result.getInt(ORDER_NUMBER_COLUMN);
        String code = result.getString(PRODUCT_CODE_COLUMN);
        String name = result.getString(PRODUCT_NAME_COLUMN);
        int quantity = result.getInt(QUANTITY_COLUMN);

        if (lastNumber != currentNumber) {
          order = new Order();
          order.setOrderDate(result.getDate(ORDER_DATE_COLUMN));

          customer.addOrder(order);
        }

        double price = result.getDouble(PRICE_COLUMN);
        Product product = new Product(code, name, price);
        order.addItem(product, quantity);
      }
    }
    catch (Exception exception) {
      throw new DataAccessException("Could not read orders for customer " + customer.getName(), exception);
    }
  }
}

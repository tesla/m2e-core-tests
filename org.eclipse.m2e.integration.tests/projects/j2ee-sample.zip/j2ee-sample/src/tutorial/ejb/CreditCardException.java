package tutorial.ejb;

public class CreditCardException extends Exception {
  public CreditCardException(String message, Exception cause) {
    super(message, cause);
  }
  public CreditCardException(String message) {
    super(message);
  }
}

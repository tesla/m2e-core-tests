package tutorial.ejb;

import javax.ejb.EJBObject;
import java.rmi.RemoteException;

public interface CreditCardService extends EJBObject {
  public void debit(String cardNumber, String expiry, double amount) throws RemoteException, CreditCardException;
}

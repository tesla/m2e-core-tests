package tutorial.ejb;

import javax.ejb.EJBHome;
import javax.ejb.CreateException;
import java.rmi.RemoteException;

public interface CreditCardServiceHome extends EJBHome {
  tutorial.ejb.CreditCardService create() throws RemoteException, CreateException;
}

package tutorial.hibernate;

import java.io.Serializable;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

import tutorial.web.DataAccessException;

public abstract class BaseDAO {

	protected Session createSession() {
		return HibernateUtil.createSession();
	}

	protected void save(Object obj) throws DataAccessException {
		Session session = createSession();
		Transaction tx = session.beginTransaction();
		try {
			session.saveOrUpdate(obj);
			tx.commit();
		} catch (HibernateException ex) {
			tx.rollback();
			throw new DataAccessException("Could not save " + obj, ex);
		} finally {
			session.close();
		}
	}

	public Object getObjectById(Class clazz, Serializable id)
			throws DataAccessException {
		if (id == null) {
			return null;
		}
		Session session = createSession();
		try {			
			return createSession().get(clazz, id);
		} catch (HibernateException hex) {
			throw new DataAccessException("Problem loading " + clazz.getName()
					+ " object with id=" + id, hex);
		} finally {
			session.close();
		}
	}

}

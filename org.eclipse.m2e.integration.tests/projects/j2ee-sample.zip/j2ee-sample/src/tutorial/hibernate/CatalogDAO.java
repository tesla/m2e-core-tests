package tutorial.hibernate;

import tutorial.Product;
import tutorial.web.Catalog;
import tutorial.web.DataAccessException;

import java.util.Iterator;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;

public class CatalogDAO extends BaseDAO {
   
  public Catalog getCatalog() throws DataAccessException {
    Catalog catalog = new Catalog();
    Session session = createSession();
    try { 
      Query query = session.createQuery("from " + Product.class.getName());
      List products = query.list();
      for (Iterator iter = products.iterator(); iter.hasNext();) {
        Product element = (Product) iter.next();
        catalog.addProduct(element);
      }     
    } catch (HibernateException exception) {
      throw new DataAccessException("Could not read catalog details", exception);
    } finally {
    	session.close();
    }
    return catalog;
  }  

}

package tutorial.hibernate;

import java.util.NoSuchElementException;

import tutorial.Customer;
import tutorial.web.DataAccessException;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.StaleObjectStateException;

class CustomerDAO extends BaseDAO {

	public Customer getCustomer(String customerName) throws DataAccessException {
		Session session = createSession();
		try {
			Query hQ = session.createQuery(
					"from Customer c where c.name = :name").setString("name",
					customerName);
			Customer customer = (Customer) hQ.uniqueResult();
			if (customer == null) {
				throw new NoSuchElementException("Customer does not exist ["
						+ customerName + "]");
			}
			return customer;
		} catch (HibernateException exception) {
			throw new DataAccessException("Could not read customer details",
					exception);
		} finally {
			session.close();
		}
	}

	/**
	 * Implements application version checking. Reloads the persistent instances
	 * from the datastore before manipulating them.
	 */
	public void updateCustomer(Customer updatedCustomer) throws DataAccessException {
		Customer existingCustomer = (Customer) getObjectById(Customer.class, updatedCustomer.getId());
		if (existingCustomer != null) {
			if (existingCustomer.getVersion() > updatedCustomer.getVersion()) {
				throw new DataAccessException("Could not update customer",
						new StaleObjectStateException(Customer.class.getName(),
								updatedCustomer.getId().toString()));
			}
		}
		save(updatedCustomer);
	}

}

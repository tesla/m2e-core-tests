package tutorial.hibernate;

import tutorial.Customer;
import tutorial.Order;
import tutorial.Product;
import tutorial.web.Catalog;
import tutorial.web.DataAccess;
import tutorial.web.DataAccessException;

public class HibernateDataAccess implements DataAccess {

  public Product getProduct(String productCode) throws DataAccessException {
    return new ProductDAO().getProduct(productCode);
  }

  public Catalog getCatalog() throws DataAccessException {
    return new CatalogDAO().getCatalog();
  }

  /*
   * Order is contained in Customer.  The Customer.addOrder method creates the association 
   * between these two objects.  Thus the parameter is not used in the Hibernate implemenation.
   */
  public void saveOrder(Customer customer, Order order) throws DataAccessException {
    new CustomerDAO().updateCustomer(customer);    
  }

  public Customer getCustomer(String name) throws DataAccessException {
    return new CustomerDAO().getCustomer(name);
  }
  
}

package tutorial.web;

import tutorial.CreditException;
import tutorial.Customer;
import tutorial.Order;
import tutorial.Product;

public class CannedDataAccess implements DataAccess {
  private Catalog catalog;
  protected Order savedOrder; 

  public CannedDataAccess() {
    catalog = new Catalog();

    addProduct("A-1234-56-A", "Snowboard", 350);
    addProduct("A-1234-78-A", "Boots", 125);
    addProduct("A-1234-90-A", "Goggles", 72);
  }

  private void addProduct(String code, String name, int price) {
    Product product = new Product(code, name, price);
    catalog.addProduct(product);
  }

  public Product getProduct(String productCode) {
    return catalog.getProduct(productCode);
  }

  public Catalog getCatalog() {
    return catalog;
  }

  public void saveOrder(Customer customer, Order order) {
    try {
      customer.addOrder(order);
    } catch (CreditException exception) {
      exception.printStackTrace();
    }
    this.savedOrder = order;
  }

  public Customer getCustomer(String name) {
    return new Customer(name);
  }
}

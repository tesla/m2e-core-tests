package tutorial.web;

import tutorial.Product;
import java.util.HashMap;
import java.util.Iterator;

public class Catalog {
  private HashMap products;

  public Catalog() {
    products = new HashMap();
  }

  public void addProduct(Product product) {
    products.put(product.getCode(), product);
  }

  public Product getProduct(String productCode) {
    return (Product) products.get(productCode);
  }

  public Iterator getProducts(){
    return products.values().iterator();
  }

  public String toString() {
    return products.toString();
  }
  
  public int getProductCount() {
    return products.size();
  }
  
}

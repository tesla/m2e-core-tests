package tutorial.web;

import tutorial.Order;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;

public class CheckoutAction extends WebAction {
  public CheckoutAction() {
    super("checkout");
  }

  public void process(HttpServletRequest request) throws ServletException {
    try {
      String cardNumber = request.getParameter("credit-card");
      String expiration = request.getParameter("expiration");

      Order order = getShoppingCart(request).getOrder();

      CreditCard card = new CreditCard(cardNumber, expiration);
      card.debit(order.getTotalCost());
    }
    catch (Exception exception) {
      throw new ServletException("Could not checkout", exception);
    }
  }
}

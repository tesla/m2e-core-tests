package tutorial.web;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.ServletException;
import javax.servlet.ServletConfig;
import java.io.*;
import java.util.HashMap;

public class Controller extends HttpServlet {
  private static final String DATA_ACCESS_INITIALIZATION_ERROR = "Could not create data access object";
  private static final String ACTION_INITIALIZATION_ERROR = "Could not initialize actions";
  private static final String ACTION_FILE_NOT_FOUND = "Action definition file not found";
  private static final String ACTIONS_FILE = "/WEB-INF/actions.txt";
  private static final String PAGE_PARAMETER = "page";
  private static final String HOME_PAGE = "/index.jsp";

  private DataAccess dataAccess;
  private HashMap actions;

  public void init(ServletConfig config) throws ServletException {
    super.init(config);
    createDataAccessObject(config.getInitParameter("data-access-object"));
    createActions(config.getServletContext().getResourceAsStream(ACTIONS_FILE));
    loadCatalog();
  }

  protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    String uri = request.getServletPath();
    int index = uri.indexOf(".do");
    if(index > 1){
      WebAction action = (WebAction) actions.get(uri.substring(1, index));
      if(action != null){
        action.process(request);
      }
    }

    String nextPage = request.getParameter(PAGE_PARAMETER);
    if (nextPage == null) {
      nextPage = HOME_PAGE;
    }
    request.getRequestDispatcher(nextPage).forward(request, response);
  }

  private void createDataAccessObject(String className) throws ServletException {
    try {
      dataAccess = (DataAccess) Class.forName(className).newInstance();
    }
    catch (Exception exception) {
      throw new ServletException(DATA_ACCESS_INITIALIZATION_ERROR + "-" + className, exception);
    }
  }

  private void createActions(InputStream actionFile) throws ServletException {
    if(actionFile == null){
      throw new ServletException(ACTION_FILE_NOT_FOUND);
    }

    try {
      BufferedReader in = new BufferedReader(new InputStreamReader(actionFile));
      actions = new HashMap();
      for(String action = in.readLine();
          action != null;
          action = in.readLine()){
        addAction((WebAction) Class.forName(action).newInstance());
      }
    }
    catch (Exception exception) {
      throw new ServletException(ACTION_INITIALIZATION_ERROR, exception);
    }
    finally {
      try {
        actionFile.close();
      }
      catch (IOException ignore) {
        log("Could not close action file", ignore);
      }
    }
  }

  private void addAction(WebAction action) {
    action.init(dataAccess);
    actions.put(action.getName(), action);
  }

  private void loadCatalog() throws ServletException {
    try {
      getServletContext().setAttribute("catalog", dataAccess.getCatalog());
    } catch (DataAccessException exception) {
      throw new ServletException("Could not load catalog", exception);
    }
  }
}

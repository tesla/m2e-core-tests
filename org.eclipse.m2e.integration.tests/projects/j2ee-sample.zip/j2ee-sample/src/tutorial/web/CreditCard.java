package tutorial.web;

import tutorial.ejb.CreditCardException;
import tutorial.ejb.CreditCardServiceHome;
import tutorial.ejb.CreditCardService;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.rmi.PortableRemoteObject;
import javax.ejb.CreateException;
import java.rmi.RemoteException;

public class CreditCard {
  static final String JNDI_NAME = "java:comp/env/ejb/CreditCardService";

  private String cardNumber;
  private String expiry;


  public CreditCard(String cardNumber, String expiry) {
    this.cardNumber = cardNumber;
    this.expiry = expiry;
  }

  public void debit(double totalCost) throws CreditCardException {
    try {
      CreditCardService service = getCreditCardService();
      service.debit(cardNumber, expiry,  totalCost);
    }
    catch (CreditCardException e) {
      throw e;
    }
    catch (Exception e) {
      throw new CreditCardException("Could not debit credit card", e);
    }
  }

  static CreditCardService getCreditCardService() throws NamingException, RemoteException, CreateException {
    InitialContext context = new InitialContext();

    Object object = context.lookup(JNDI_NAME);
    CreditCardServiceHome home = (CreditCardServiceHome) PortableRemoteObject.narrow(object, CreditCardServiceHome.class);

    return home.create();
  }
}

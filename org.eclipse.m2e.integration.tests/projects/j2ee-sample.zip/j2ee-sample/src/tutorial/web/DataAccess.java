package tutorial.web;

import tutorial.Product;
import tutorial.Order;
import tutorial.Customer;

public interface DataAccess {
  Catalog getCatalog() throws DataAccessException;
  Product getProduct(String productCode) throws DataAccessException;
  void saveOrder(Customer customer, Order order) throws DataAccessException;
  Customer getCustomer(String name) throws DataAccessException;
}

package tutorial.web;

import tutorial.CreditException;
import tutorial.print.Invoice;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import java.security.Principal;

public class InvoiceAction extends WebAction {
  public InvoiceAction() {
    super("invoice");
  }

  public void process(HttpServletRequest request) throws ServletException {
    try {
      Principal userPrincipal = request.getUserPrincipal();
      Invoice invoice = getShoppingCart(request).checkout(userPrincipal.getName());
      request.setAttribute(INVOICE, invoice);
      resetShoppingCart(request);
    } catch (CreditException exception) {
      throw new ServletException("Could not checkout", exception);
    } catch (DataAccessException exception) {
      throw new ServletException("Could not checkout", exception);
    }
  }
}

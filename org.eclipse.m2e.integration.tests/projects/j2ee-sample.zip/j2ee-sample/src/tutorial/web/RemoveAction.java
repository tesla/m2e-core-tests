package tutorial.web;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.ServletException;

public class RemoveAction extends WebAction {
  public RemoveAction() {
    super("remove");
  }

  public void process(HttpServletRequest request) throws ServletException {
    String code = request.getParameter("product-code");
    try {
      getShoppingCart(request).removeItem(code);
    }
    catch (DataAccessException e) {
      throw new ServletException("Could not remove item [" + code + "]");
    }
  }
}

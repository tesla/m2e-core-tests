package tutorial.web;

import tutorial.CreditException;
import tutorial.Customer;
import tutorial.Order;
import tutorial.Product;
import tutorial.print.Invoice;
import java.util.HashMap;
import java.util.Iterator;


public class ShoppingCart {
  private DataAccess dataAccess;
  private HashMap items;
  private Catalog catalog;

  public ShoppingCart(DataAccess dataAccess) throws DataAccessException {
    if(dataAccess == null){
      throw new IllegalArgumentException("DataAccess must not be null");
    }
    this.dataAccess = dataAccess;
    this.catalog = dataAccess.getCatalog();
    this.items = new HashMap();
  }

  public synchronized void addItem(String productCode) {
    Integer quantity = (Integer) items.get(productCode);
    if(quantity == null) {
      updateQuantity(productCode, 1);
    }
    else {
      updateQuantity(productCode, quantity.intValue() + 1);
    }
  }

  public synchronized void updateQuantity(String productCode, int quantity) {
    if (catalog.getProduct(productCode) == null) {
      throw new IllegalArgumentException("Product not found - " + productCode);
    }
    if(quantity < 0){
      throw new IllegalArgumentException("Quantity cannot be negative");
    }
    items.put(productCode, new Integer(quantity));
  }

  public synchronized void removeItem(String productCode) {
    items.remove(productCode);
  }

  public synchronized Order getOrder() throws DataAccessException {
    Order order = new Order();
    Iterator keys = items.keySet().iterator();
    while (keys.hasNext()) {
      String productCode = (String) keys.next();
      int quantity = ((Integer) items.get(productCode)).intValue();
      order.addItem(getProduct(productCode), quantity);
    }
    return order;
  }

  public synchronized Invoice checkout(String user) throws DataAccessException, CreditException {
    Order order = getOrder();
    Customer customer = new Customer(user);
    customer.addOrder(order);    
    dataAccess.saveOrder(customer, order);
    return new Invoice(dataAccess.getCustomer(user), order);
  }

  private Product getProduct(String productCode) throws DataAccessException {
    return dataAccess.getProduct(productCode);
  }

  public String toString() {
    return "[ShoppingCart items=" + items + "]";
  }
}

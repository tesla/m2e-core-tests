package tutorial.web;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;

public abstract class WebAction {
  public static final String CART = "shopping-cart";
  public static final String ORDER = "order";
  public static final String INVOICE = "invoice";

  private DataAccess dataAccess;
  private String name;

  protected WebAction(String name) {
    this.name = name;
  }

  public void init(DataAccess dataAccess){
    this.dataAccess = dataAccess;
  }

  public abstract void process(HttpServletRequest request) throws ServletException;

  public String getName() {
    return name;
  }

  protected ShoppingCart getShoppingCart(HttpServletRequest request) throws DataAccessException {
    ShoppingCart cart = (ShoppingCart) request.getSession().getAttribute(CART);
    if(cart == null){
      cart = new ShoppingCart(dataAccess);
      request.getSession().setAttribute(CART, cart);
    }
    return cart;
  }

  protected void resetShoppingCart(HttpServletRequest request) {
    request.getSession().removeAttribute(CART);
  }
}

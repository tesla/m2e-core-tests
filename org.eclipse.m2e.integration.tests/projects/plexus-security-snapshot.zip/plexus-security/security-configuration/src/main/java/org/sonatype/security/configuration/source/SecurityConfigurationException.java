package org.sonatype.security.configuration.source;

public class SecurityConfigurationException
    extends Exception
{

    public SecurityConfigurationException()
    {
        // TODO Auto-generated constructor stub
    }

    public SecurityConfigurationException( String message )
    {
        super( message );
        // TODO Auto-generated constructor stub
    }

    public SecurityConfigurationException( Throwable cause )
    {
        super( cause );
        // TODO Auto-generated constructor stub
    }

    public SecurityConfigurationException( String message, Throwable cause )
    {
        super( message, cause );
        // TODO Auto-generated constructor stub
    }

}

package org.sonatype.security.authorization;

public interface Permission
{

}

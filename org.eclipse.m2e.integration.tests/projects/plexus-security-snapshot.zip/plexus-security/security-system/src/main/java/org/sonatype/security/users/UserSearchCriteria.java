package org.sonatype.security.users;

public class UserSearchCriteria
{

}

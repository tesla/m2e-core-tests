package org.sonatype.test.versionProject2;

public class Simple {

	public int add(int a, int b) {
		return a+b;
	}
}

package org.sonatype.test.project;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	ShortOptionHandler s;
        System.out.println( "Hello World!" );
    }
}

package tutorial;

public class CreditException extends Exception {
  public CreditException(String message) {
    super(message);
  }
}

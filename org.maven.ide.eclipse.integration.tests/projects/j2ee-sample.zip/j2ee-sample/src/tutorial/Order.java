package tutorial;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

public class Order {
  private Integer id;
  private Customer customer;
  private Date orderDate;
  private List items;

  public Order() {
    orderDate = new Date();
    items = new ArrayList();
  }

  public void addItem(Product product, int quantity) {
    OrderItem item = new OrderItem(product, quantity);
    items.add(item);
    item.setOrder(this);
  }

  public OrderItem[] getItemsArray() {
    return (OrderItem[]) items.toArray(new OrderItem[items.size()]);
  }

  public double getTotalCost() {
    double total = 0;
    for (Iterator iterator = items.iterator(); iterator.hasNext();) {
      OrderItem item = (OrderItem) iterator.next();
      total += item.getCost();
    }
    return total;
  }

  public double getTax() {
    return getTotalCost() * 8 / 100;
  }

  public double getDiscount() {
    double total = getTotalCost();
    return total > 500
           ? total * 10 / 100
           : 0;
  }

  public double getAmountDue() {
    return getTotalCost() + getTax() - getDiscount();
  }

  public Date getOrderDate() {
    return orderDate;
  }

  public void setOrderDate(Date orderDate) {
    if (orderDate == null) {
      throw new IllegalArgumentException("Order date cannot be null");
    }
    this.orderDate = orderDate;
  }

  public String toString() {
    return "Order - " + items.size() + " item(s)";
  }

  // This method is used for testing
  private static Order createForTesting(Product[] products) {
    Order order = new Order();
    for (int i = 0; i < products.length; i++) {
      order.addItem(products[i], i);
    }
    return order;
  }

  
  public Integer getId() {
    return id;
  }

  
  public void setId(Integer id) {
    this.id = id;
  }

  
  public Customer getCustomer() {
    return customer;
  }

  
  public void setCustomer(Customer customer) {
    this.customer = customer;
  }
  
  public List getItems() {
    return this.items;
  }
  
  public void setItems(List items) {
    this.items = items;
  }
}



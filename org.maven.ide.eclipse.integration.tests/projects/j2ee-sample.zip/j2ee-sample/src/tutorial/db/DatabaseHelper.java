package tutorial.db;

import tutorial.web.DataAccessException;
import java.sql.*;

class DatabaseHelper {
  private Connection connection;

  DatabaseHelper(Connection connection) {
    if(connection == null){
      throw new NullPointerException("connection must not be null");
    }
    this.connection = connection;
  }

  ResultSet select(String sqlStatement, String primaryKey) throws SQLException {
    PreparedStatement statement = connection.prepareStatement(sqlStatement);
    statement.setString(1, primaryKey);
    statement.execute();
    return statement.getResultSet();
  }

  ResultSet select(String sqlStatement) throws SQLException {
    Statement statement = connection.createStatement();
    statement.executeQuery(sqlStatement);
    return statement.getResultSet();
  }

  void insert(String sqlStatement, Object[] parameters) throws SQLException {
    PreparedStatement statement = connection.prepareStatement(sqlStatement);
    for (int i = 0; i < parameters.length; i++) {
      statement.setObject(i + 1, parameters[i]);
    }
    statement.executeUpdate(sqlStatement);
  }

  void disconnect() throws DataAccessException {
    try {
      connection.close();
    }
    catch (SQLException exception) {
      throw new DataAccessException("Could not disconnect from database", exception);
    }
  }
}

package tutorial.db;

import tutorial.Product;
import tutorial.web.DataAccessException;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.NoSuchElementException;

public class ProductDAO {
  private static final String SELECT_PRODUCT = "select productName, price from Products where productCode = ?";

  private static final int PRODUCT_NAME_COLUMN = 1;
  private static final int PRODUCT_PRICE_COLUMN = 2;

  private final DatabaseHelper db;

  public ProductDAO(DatabaseHelper db) {
    if (db == null) {
      throw new NullPointerException("db must not be null");
    }
    this.db = db;
  }

  public Product getProduct(String productCode) throws DataAccessException {
    try {
      ResultSet result = db.select(SELECT_PRODUCT, productCode);
      return readProduct(result, productCode);
    }
    catch (SQLException exception) {
      throw new DataAccessException("Could not read details for product [" + productCode + "]", exception);
    }
  }

  private Product readProduct(ResultSet result, String productCode) throws SQLException {
    if (result.next()) {
      double price = result.getDouble(PRODUCT_PRICE_COLUMN);
      return new Product(productCode, result.getString(PRODUCT_NAME_COLUMN), price);
    }
    else {
      throw new NoSuchElementException("Product does not exist [" + productCode + "]");
    }
  }

}

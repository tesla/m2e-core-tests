package tutorial.ejb;

import javax.ejb.SessionBean;
import javax.ejb.CreateException;
import javax.ejb.SessionContext;
import javax.ejb.EJBException;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.text.DateFormat;
import java.util.Date;

public class CreditCardServiceBean implements SessionBean {
  private static final DateFormat formatter = new SimpleDateFormat("MM/yyyy");
  private Double maxDebit;

  public CreditCardServiceBean() {
  }

  public void ejbCreate() throws CreateException {
    try {
      InitialContext context = new InitialContext();
      maxDebit = (Double) context.lookup("java:comp/env/MaxDebit");
    }
    catch (NamingException e) {
      throw new CreateException("Could not access JNDI");
    }
  }

  public void setSessionContext(SessionContext context) throws EJBException {
  }

  public void ejbRemove() throws EJBException {
  }

  public void ejbActivate() throws EJBException {
  }

  public void ejbPassivate() throws EJBException {
  }

  public void debit(String cardNumber, String expiry, double amount) throws CreditCardException {
    if (!cardNumber.matches("[0-9]{16,16}")) {
      throw new CreditCardException("Invalid Card Number");
    }

    try {
      Date date = formatter.parse(expiry);
      if (new Date().after(date)) {
        throw new CreditCardException("Card has expired");
      }

    }
    catch (ParseException e) {
      throw new CreditCardException("Expiry date is invalid");
    }

    if (amount < 0) {
      throw new CreditCardException("Amount must not be negative");
    }

    if (amount > maxDebit.doubleValue()) {
      throw new CreditCardException("Maximum debit exceeded");
    }
  }
}

package tutorial.hibernate;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;

import tutorial.CreditException;
import tutorial.Customer;
import tutorial.Order;
import tutorial.Product;

/**
 * This class helps with the creation of initial data in  
 * J2EE tutorial: Agitating Hibernate Applications 
 */
public class HibernateTestHelper {

	private static String[] PRODUCT_NAMES = { "Snowboard", "Boots", "Goggles" };

	private static String[] PRODUCT_CODES = { "A-1234-56-A", "A-1234-78-A",
			"A-1234-90-A" };

	private static int[] PRODUCT_PRICES = { 350, 125, 72 };

	private static String[] CUSTOMER_NAMES = { "Bob", "Kevin", "Beth" };

	private static Random rnd = new Random();

	/**
	 * Returns an Iteration of Product objects to be used by a global factory
	 * 
	 * @return an Iterator of Product objects
	 */
	public static Iterator generateProducts() {
		ArrayList products = new ArrayList();
		for (int i = 0; i < PRODUCT_CODES.length; i++) {
			products.add(new Product(PRODUCT_CODES[i], PRODUCT_NAMES[i],
					PRODUCT_PRICES[i]));
		}
		return products.iterator();
	}

	/**
	 * Returns an Iteration of Customer objects to be used by a global factory
	 * 
	 * @return an Iterator of Customer objects
	 */
	public static Iterator generateCustomers() {
		ArrayList customers = new ArrayList();
		for (int i = 0; i < CUSTOMER_NAMES.length; i++) {
			Customer customer = new Customer(CUSTOMER_NAMES[i]);
			customer.setCreditLimit(10000);
			try {
				customer.addOrder(generateOrder());
			} catch (CreditException cex) {
				cex.printStackTrace();
			}
			customers.add(customer);
		}
		return customers.iterator();
	}

	/**
	 * Returns a random selection of customer names of objects provided by the
	 * global factory
	 * 
	 * @return a customer name
	 */
	public static String getCustomerNames() {
		return (String) CUSTOMER_NAMES[rnd.nextInt(3)];
	}

	private static Order generateOrder() {
		Order order = new Order();
		for (Iterator iter = generateProducts(); iter.hasNext();) {
			int itemCount = rnd.nextInt(5);
			order.addItem((Product) iter.next(), itemCount);
		}
		return order;
	}

}

package tutorial.hibernate;

import org.hibernate.*;
import org.hibernate.cfg.*;
import org.apache.commons.logging.*;

import tutorial.Customer;
import tutorial.Order;
import tutorial.OrderItem;
import tutorial.Product;

/**
 * Copied from Hibernate In Action book CaveatEmptor example.
 * 
 * Basic Hibernate helper class for Hibernate configuration and startup.
 * <p>
 * Uses a static initializer to read startup options and initialize
 * <tt>Configuration</tt> and <tt>SessionFactory</tt>. 
 */
public class HibernateUtil {

	private static Log log = LogFactory.getLog(HibernateUtil.class);

	private static Configuration configuration;

	private static SessionFactory sessionFactory;

	static {
		// Create the initial SessionFactory from the default hibernate.cfg.xml
		try {
			configuration = new Configuration();
			configuration.configure();
			configuration.addClass(Customer.class);
			configuration.addClass(Product.class);
			configuration.addClass(Order.class);
			configuration.addClass(OrderItem.class);
			sessionFactory = configuration.buildSessionFactory();
		} catch (Throwable ex) {
			// We have to catch Throwable, otherwise we will miss
			// NoClassDefFoundError and other subclasses of Error
			log.error("Building SessionFactory failed.", ex);
			throw new ExceptionInInitializerError(ex);
		}
	}

	/**
	 * Returns the original Hibernate configuration.
	 * 
	 * @return Configuration
	 */
	public static Configuration getConfiguration() {
		return configuration;
	}

	/**
	 * Returns the global SessionFactory.
	 * 
	 * @return SessionFactory
	 */
	public static SessionFactory getSessionFactory() {
		if (sessionFactory == null) {
			throw new IllegalStateException("SessionFactory not available.");
		}
		return sessionFactory;
	}

	/**
	 * Closes the current SessionFactory and releases all resources.
	 * <p>
	 * The only other method that can be called on HibernateUtil after this one
	 * is rebuildSessionFactory(Configuration).
	 */
	public static void shutdown() {
		log.debug("Shutting down Hibernate.");
		// Close caches and connection pools
		getSessionFactory().close();

		// Clear static variables
		configuration = null;
		sessionFactory = null;
	}

	/**
	 * Rebuild the SessionFactory with the static Configuration.
	 * <p>
	 * This method also closes the old SessionFactory before, if still open.
	 * Note that this method should only be used with static SessionFactory
	 * management, not with JNDI or any other external registry.
	 */
	public static void rebuildSessionFactory() {
		log.debug("Using current Configuration for rebuild.");
		rebuildSessionFactory(configuration);
	}

	/**
	 * Rebuild the SessionFactory with the given Hibernate Configuration.
	 * <p>
	 * HibernateUtil does not configure() the given Configuration object, it
	 * directly calls buildSessionFactory(). This method also closes the old
	 * SessionFactory before, if still open.
	 * 
	 * @param cfg
	 */
	public static void rebuildSessionFactory(Configuration cfg) {
		log.debug("Rebuilding the SessionFactory from given Configuration.");
		if (sessionFactory != null && !sessionFactory.isClosed()) {
			sessionFactory.close();
		}
		configuration = cfg;
		if (configuration == null) {
			configuration = new Configuration();
		}	
		sessionFactory = configuration.buildSessionFactory();		
	}

	public static Session createSession() {
		return getSessionFactory().openSession();
	}

}

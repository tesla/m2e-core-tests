package tutorial.hibernate;

import java.util.NoSuchElementException;

import tutorial.Product;
import tutorial.web.DataAccessException;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;

public class ProductDAO extends BaseDAO {

	public Product getProduct(String productCode) throws DataAccessException {
		Session session = createSession();
		try {
			Query hQ = session.createQuery(
					"from Product p where p.code = :code").setString("code",
					productCode);
			Product product = (Product) hQ.uniqueResult();
			if (product == null) {
				throw new NoSuchElementException("Product does not exist ["
						+ productCode + "]");
			}
			return product;
		} catch (HibernateException exception) {
			throw new DataAccessException(
					"Could not read details for product [" + productCode + "]",
					exception);
		} finally {
			session.close();
		}
	}

}

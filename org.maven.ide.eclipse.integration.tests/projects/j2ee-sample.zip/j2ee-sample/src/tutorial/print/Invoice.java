package tutorial.print;

import tutorial.CreditException;
import tutorial.Customer;
import tutorial.Order;
import tutorial.OrderItem;
import tutorial.Product;

import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;

public class Invoice {

  private static final String HEADER = "Product Code\tProduct Name        \t    Price\tQuantity\t   Amount";
  private static final String HEADER_UNDERLINE = "============\t====================\t=========\t========\t=========";
  private static final String UNDERLINE = "            \t                    \t         \t        \t=========";
  private static final String TABS = "            \t                    \t         \t";

  private Customer customer;
  private Order order;
  private DateFormat dateFormat;
  private NumberFormat numberFormat;

  public Invoice(Customer customer, Order order) {
    if (customer == null) {
      throw new IllegalArgumentException("Customer cannot be null");
    }
    if (order == null) {
      throw new IllegalArgumentException("Order cannot be null");
    }
    this.customer = customer;
    this.order = order;

    dateFormat = new SimpleDateFormat("MMMM dd, yyyy");
    numberFormat = new DecimalFormat("$#,##0.00");
  }

  public void print(PrintWriter out) {
    printHeaders(out);
    printItems(out);
    printTotals(out);
  }

  private void printHeaders(PrintWriter out) {
    out.print("  Customer : ");
    out.println(customer.getName());
    out.print("Ordered On : ");
    out.println(dateFormat.format(order.getOrderDate()));
    out.println();
  }

  private void printItems(PrintWriter out) {
    out.println(HEADER);
    out.println(HEADER_UNDERLINE);
    OrderItem[] items = order.getItemsArray();
    if (items.length > 0) {
      for (int i = 0; i < items.length; i++) {
        printOrderItem(out, items[i]);
      }
    }
    else {
      out.println("No ITEMS");
    }
  }

  private void printOrderItem(PrintWriter out, OrderItem item) {
    out.print(' ');
    out.print(item.getProduct().getCode());
    out.print('\t');
    out.print(pad(item.getProduct().getName(), 20, false));
    out.print('\t');
    out.print(format(item.getProduct().getPrice()));
    out.print("\t");
    out.print(pad(Integer.toString(item.getQuantity()), 8, true));
    out.print("\t");
    out.println(format(item.getCost()));
  }

  private void printTotals(PrintWriter out) {
    out.println(UNDERLINE);
    out.print(TABS + "        \t");
    out.println(format(order.getTotalCost()));
    out.println(UNDERLINE);
    out.print(TABS + "Tax     \t");
    out.println(format(order.getTax()));
    out.print(TABS + "Discount\t");
    out.println(format(order.getDiscount()));
    out.println(UNDERLINE);
    out.print(TABS + "Total   \t");
    out.println(format(order.getAmountDue()));
  }

  private String format(double price) {
    return pad(numberFormat.format(price), 9, true);
  }

  private String pad(String name, int length, boolean left) {
    StringBuffer buffer = new StringBuffer(length);
    int pad = length - name.length();
    while (left && pad-- > 0) {
      buffer.append(' ');
    }
    buffer.append(name);
    while (!left && pad-- > 0) {
      buffer.append(' ');
    }
    return buffer.toString();
  }

  public static void main(String[] args) throws CreditException {
    Customer customer = new Customer("George Banks");
    customer.setCreditLimit(1000);

    Product board = new Product("A-1234-56-B", "Snowboard", 600);
    Product goggles = new Product("X-5678-90-Y", "Goggles", 75);
    Product boots = new Product("M-3456-22-N", "Boots", 200);

    Order order = new Order();
    order.addItem(board, 1);
    order.addItem(goggles, 2);
    order.addItem(boots, 1);

    customer.addOrder(order);

    Invoice invoice = new Invoice(customer, order);

    PrintWriter out = new PrintWriter(System.out);
    invoice.print(out);
    out.flush();
  }
}

package tutorial.web;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.ServletException;

public class BuyAction extends WebAction {
  public BuyAction() {
    super("buy");
  }

  public void process(HttpServletRequest request) throws ServletException {
    try {
      getShoppingCart(request).addItem(request.getParameter("product-code"));
    }
    catch(Exception exception){
      throw new ServletException("Could not update shopping cart", exception);
    }
  }

}

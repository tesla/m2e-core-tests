package tutorial.web;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.ServletException;

public class ShowCartAction extends WebAction {
  public ShowCartAction() {
    super("show-cart");
  }

  public boolean requiresLogin() {
    return false;
  }

  public void process(HttpServletRequest request) throws ServletException {
    try {
      request.setAttribute(ORDER, getShoppingCart(request).getOrder());
    }
    catch (DataAccessException exception) {
      throw new ServletException("Could not create shopping cart", exception);
    }
  }
}

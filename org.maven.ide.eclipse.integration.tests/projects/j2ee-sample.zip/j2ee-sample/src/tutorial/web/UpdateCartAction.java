package tutorial.web;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.ServletException;

public class UpdateCartAction extends WebAction {
  public UpdateCartAction() {
    super("update-cart");
  }

  public void process(HttpServletRequest request) throws ServletException {
    try {
      String productCode = request.getParameter("product-code");
      String quantity = request.getParameter("quantity");
      getShoppingCart(request).updateQuantity(productCode, Integer.parseInt(quantity));
    }
    catch(Exception exception){
      throw new ServletException("Could not update shopping cart");
    }
  }
}


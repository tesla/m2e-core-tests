package org.sonatype.test.ResolveDepProject;

public class App 
{
    public static void main( String[] args )
    {
       JFreeChart.main(args);
    }
}

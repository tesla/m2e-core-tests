package org.sonatype.test.project;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        try {
        	Configuration configuration = new org.hibernate.cfg.Configuration();
            configuration.configure();
            SessionFactory sessionFactory = configuration.buildSessionFactory();
    } catch (Exception ex) {
            ex.printStackTrace();
    }

        System.out.println( "Hello World!" );
    }
}

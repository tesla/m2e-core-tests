package org.sonatype.test.project;

public class App 
{
    public static void main( String[] args )
    {
       SessionFactory sessionFactory = null;
    }
}

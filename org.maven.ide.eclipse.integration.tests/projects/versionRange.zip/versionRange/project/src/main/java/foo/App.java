package foo;

import org.sonatype.test.project2.Simple;


/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println(new Simple().add(1, 2));
    }
}
